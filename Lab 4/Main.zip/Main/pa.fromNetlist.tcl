
# PlanAhead Launch Script for Post-Synthesis pin planning, created by Project Navigator

create_project -name Main -dir "C:/Users/Mahyar Onsori/Desktop/Report 4/Main/planAhead_run_2" -part xc6slx9tqg144-3
set_property design_mode GateLvl [get_property srcset [current_run -impl]]
set_property edif_top_file "C:/Users/Mahyar Onsori/Desktop/Report 4/Main/Main.ngc" [ get_property srcset [ current_run ] ]
add_files -norecurse { {C:/Users/Mahyar Onsori/Desktop/Report 4/Main} }
set_param project.pinAheadLayout  yes
set_property target_constrs_file "Main.ucf" [current_fileset -constrset]
add_files [list {Main.ucf}] -fileset [get_property constrset [current_run]]
link_design
