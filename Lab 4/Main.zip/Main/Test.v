`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   03:19:14 05/14/2021
// Design Name:   Main
// Module Name:   C:/Users/Mahyar Onsori/Desktop/Report 4/Main/Test.v
// Project Name:  Main
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: Main
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module Test;

	// Inputs
	reg clk;
	reg Car_in_street;

	// Outputs
	wire Highway_Green;
	wire Highway_Yellow;
	wire Highway_Red;
	wire Street_Green;
	wire Street_Yellow;
	wire Street_Red;
	wire [3:0] en_7seg;
	wire [7:0] sevenseg;

	// Instantiate the Unit Under Test (UUT)
	Main uut (
		.clk(clk), 
		.Car_in_street(Car_in_street), 
		.Highway_Green(Highway_Green), 
		.Highway_Yellow(Highway_Yellow), 
		.Highway_Red(Highway_Red), 
		.Street_Green(Street_Green), 
		.Street_Yellow(Street_Yellow), 
		.Street_Red(Street_Red),
		.en_7seg(en_7seg),
		.sevenseg(sevenseg) 
	);

	initial begin
		// Initialize Inputs
		clk = 0;
		Car_in_street = 0;

		// Wait 100 ns for global reset to finish
		#1030;
        
		@(posedge clk) Car_in_street <= 1;
		#1030;
		@(posedge clk) Car_in_street <= 0;
		#1030;
		@(posedge clk) Car_in_street <= 1;
		@(posedge clk) Car_in_street <= 0;
		

		 
	end
always #20.833 clk = ~clk;
	      
endmodule

