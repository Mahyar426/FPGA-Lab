onerror {resume}
wave add /
run 4600 ns;
