`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    02:01:59 05/14/2021 
// Design Name: 
// Module Name:    Main 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Main(
    input clk,
    input Car_in_street,
    output reg Highway_Green = 1 ,
    output reg Highway_Yellow = 0 ,
    output reg Highway_Red = 0 ,
    output reg Street_Green = 0 ,
    output reg Street_Yellow = 0 ,
    output reg Street_Red = 1 ,
	 output reg [3:0]  en_7seg = 4'b1110 ,
	 output reg [7:0] sevenseg
    );
//---------------------------------------------------	 Defining Parameters

reg clk1Hz = 0;	 
reg Sensor = 0;
reg [2:0]  Next_state , Current_state;
reg [1:0]  Counter_2_Seconds = 2;
reg [2:0]  Counter_5_Seconds = 5;
reg [3:0]  Counter_15_Seconds = 15;
reg [3:0]  Time = 0;
reg [27:0] Counter = 0;

//--------------------------------------------------- Registering the Input

always @(posedge clk) begin
Sensor <= Car_in_street;
end

//--------------------------------------------------- Defining Local Parameters

//------------------ States
localparam [2:0]
    s1 = 3'b000,
	 s2 = 3'b001, 
	 s3 = 3'b010,
	 s4 = 3'b011,
	 s5 = 3'b100;
	 
//------------------ Numbers	
localparam [7:0]
    Zero     = 8'b11000000 ,    
	 One      = 8'b11111001 ,    
	 Two      = 8'b10100100 ,    
	 Three    = 8'b10110000 ,    
	 Four     = 8'b10011001 ,    
	 Five     = 8'b10010010 ,     
	 Six      = 8'b10000010 ,     
	 Seven    = 8'b11111000 ,     
	 Eight    = 8'b10000000 ,   
	 Nine     = 8'b10010000 ,   
	 Ten      = 8'b10001000 ,   
	 Eleven   = 8'b10000011 ,   
	 Twelve   = 8'b11000110 ,   
	 Thirteen = 8'b10100001 ,   
	 Fourteen = 8'b10000110 , 
	 Fifteen  = 8'b10001110 ;  
	 
//------------------------------------------------- 7SEG Table

always @(posedge clk) begin
   case(Time)
     4'b0000: sevenseg <= Zero;
	  4'b0001: sevenseg <= One;
	  4'b0010: sevenseg <= Two;
	  4'b0011: sevenseg <= Three;
	  4'b0100: sevenseg <= Four;
	  4'b0101: sevenseg <= Five;
	  4'b0110: sevenseg <= Six;
	  4'b0111: sevenseg <= Seven;
	  4'b1000: sevenseg <= Eight;
	  4'b1001: sevenseg <= Nine;
	  4'b1010: sevenseg <= Ten;
	  4'b1011: sevenseg <= Eleven;
	  4'b1100: sevenseg <= Twelve;
	  4'b1101: sevenseg <= Thirteen;
	  4'b1110: sevenseg <= Fourteen;
	  4'b1111: sevenseg <= Fifteen;
	  default: sevenseg <= Zero;
	endcase
end
//------------------------------------------------ 1 Hz Clock Generator which is commented for quick speed and response

always @(posedge clk)
   begin
          Counter = Counter + 1;
          if(Counter == 24000384) begin
              clk1Hz = ~clk1Hz;
              Counter = 0;
          end
end

//------------------------------------------------ States Description
always @(posedge clk) begin
   case(Current_state)

/////------------------ First State	  
	
	  s1:begin
	  	  Counter_15_Seconds = 15;    
		  if(Sensor) begin 
		    Next_state = s2; 
		  end
		  else begin
		    Next_state = s1; 
			 Time=4'b0000; 
		  end   
	 end
	 
/////------------------ Second State	 
 
	  s2: begin
	  	     Counter_2_Seconds = 2;      
	  	     Time = Counter_15_Seconds;
			  Counter_15_Seconds = Counter_15_Seconds - 1'b1;
			  if(Counter_15_Seconds == 0) Next_state = s3;
			  else Next_state = s2;
			 
			end
			 
/////------------------ Third State	  	  

	  s3: begin
	        Counter_5_Seconds = 5;     
	        Time = Counter_2_Seconds;
			  Counter_2_Seconds = Counter_2_Seconds - 1'b1;
	        if(Counter_2_Seconds == 0) Next_state = s4;
			  else Next_state = s3;
			  
	  end
	  
/////------------------ Fourth State
	  	    
	  s4: begin 
	       Counter_2_Seconds = 2;          
	       Time = Counter_5_Seconds;  
		    if(Sensor) begin
			 	Counter_5_Seconds = Counter_5_Seconds - 1'b1; 
			 	if(Counter_5_Seconds == 0) Next_state = s5;
			   else Next_state = s4;
		    end
		    else begin
		      Counter_5_Seconds = 5;
		      Next_state = s5; 
		    end  
	    end

/////------------------ Fifth State	  
	  
	  s5: begin
	       Time = Counter_2_Seconds;		
			 Counter_2_Seconds = Counter_2_Seconds - 1'b1;
			 if(Counter_2_Seconds == 0) Next_state = s1;
			 else  Next_state = s5;
		 end	
		
/////------------------ Default State	  	  
	  default Next_state = s1;	
	  
endcase



end


//----------------------------------------------------------- Definition of Traffic Lights


always @(posedge clk) begin
  case(Next_state)
	  s1: begin
			Highway_Green   <= 1'b1;              
			Highway_Yellow  <= 1'b0;
			Highway_Red     <= 1'b0;
			Street_Green    <= 1'b0;
			Street_Yellow   <= 1'b0;
			Street_Red      <= 1'b1;             
	  end
	  
	  s2: begin
			Highway_Green   <= 1'b1;              
			Highway_Yellow  <= 1'b0;
			Highway_Red     <= 1'b0;
			Street_Green    <= 1'b0;
			Street_Yellow   <= 1'b0;
			Street_Red      <= 1'b1;             
	  end
	  
	  s3: begin
			Highway_Green   <= 1'b0;
			Highway_Yellow  <= 1'b1;
			Highway_Red     <= 1'b0;
			Street_Green    <= 1'b0;
			Street_Yellow   <= 1'b0;
			Street_Red      <= 1'b1;
	  end
	  
	  s4: begin
			Highway_Green   <= 1'b0;
			Highway_Yellow  <= 1'b0;
			Highway_Red     <= 1'b1;
			Street_Green    <= 1'b1;
			Street_Yellow   <= 1'b0;
			Street_Red      <= 1'b0;
	  end
	  
	  s5: begin
			Highway_Green   <= 1'b0;
			Highway_Yellow  <= 1'b0;
			Highway_Red     <= 1'b1;
			Street_Green    <= 1'b0;
			Street_Yellow   <= 1'b1;
			Street_Red      <= 1'b0;
	  end
     
	  default begin
	      Highway_Green   <= 1'b1;              
			Highway_Yellow  <= 1'b0;
			Highway_Red     <= 1'b0;
			Street_Green    <= 1'b0;
			Street_Yellow   <= 1'b0;
			Street_Red      <= 1'b1;
			end
	  
endcase 
end

//--------------------------------------------- Changing States

always @(posedge clk) begin
   Current_state <= Next_state;
end

endmodule
