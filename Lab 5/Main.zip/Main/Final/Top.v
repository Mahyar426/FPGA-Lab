`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    23:41:02 06/16/2021 
// Design Name: 
// Module Name:    Top 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Top(
input clk , Start , Valid_Input , 
input [1:0] Filter ,
output LOCKED ,
output reg Valid = 0 ,
output reg [7:0] Pixel = 0,
output reg [21:0] Pixel_address = 0
    );
//------------------------------------------------------------	 
	 parameter Row = 224;     
	 parameter Column = 224;
//------------------------------------------------------------	 
	 reg Valid_1 = 0 , Valid_2 = 0 , Valid_3 = 0 , s = 0;
	 reg [1 : 0] k = 2;
	 reg [7 : 0] Mask [3:1][3:1];
	 reg [9 : 0] i = 1 , j = 1;
	 reg [15 : 0] addra = Column;
	 reg [20 : 0] Pixel_Address1 = 0 , Pixel_Address2 = 0 , Pixel_Address3 = 0 , Pixel_Address4 = 0 , Pixel_Address5 = 0;
	 wire Valid_Median , Valid_Sobel , CLK_OUT25 , CLK_OUT75;
	 wire [7 : 0] dout , Pixel_Median , Pixel_Sobel;
//------------------------------------------------------------		 
	 initial
	 begin
	    for ( i = 1 ; i < 4 ; i = i + 1 ) 
		 for ( j = 1 ; j < 4 ; j = j + 1 )
	         Mask [i][j][7:0] = 0 ;
		 
		 if ( ( i==4 ) && ( j==4 ) ) { i , j } = 2'b00;
	 end
//------------------------------------------------------------
	 always @(posedge CLK_OUT25)
	 begin
	    if ( Start && LOCKED )
		    s <= 1;
		 else if ( ( k == 3 ) && ( i == Column - 1 ) && ( j == Row - 1 ) )
		    begin
			    s <= 0;
			 end
	 end
//------------------------------------------------------------ 
 CLOCKGEN clockgen
   (// Clock in ports
    .CLK_IN1(clk),      // IN
    // Clock out ports
    .CLK_OUT25(CLK_OUT25),     // OUT clk main
    .CLK_OUT75(CLK_OUT75),     // OUT clk
    // Status and control signals
    .RESET( 1'b0 ),// IN
    .LOCKED(LOCKED)      // OUT
);

ROM_Median MedianROM (
  .clka(CLK_OUT75), // input clka
  .addra(addra), // input [15 : 0] addra
  .douta(dout) // output [7 : 0] douta
);

/*ROM_Sobel SobelROM (
  .clka(CLK_OUT75), // input clka
  .addra(addra), // input [15 : 0] addra
  .douta(dout) // output [7 : 0] douta
);*/ 
//------------------------------------------------------------
	 always @(posedge CLK_OUT75)
	 begin   
		 if ( s )
	    begin
		    if ( j < Row )
			 begin
				 if ( i < Column )
				 begin
				    if( ( j != Row - 1 ) && ( j != 0 ) )
					 begin
						 if ( Valid_Input )
							 case( k )
								 1 : addra <= i+ ( j ) * Column;
								 2 : addra <= i + ( j - 1 ) * Column;
								 3 : if ( ( i == 0 ) & ( j == 1 ) & ( k < 2 ) ) addra <= 2 * Column;
								   else if ( ( i == Column - 1 ) & ( j == Row - 2 ) & ( k == 3 ) ) addra <= ( Column - 1 ) * ( Row - 2 );
								   else addra <= i + 1 + ( j + 1 ) * Column;
							 endcase
						 
						 if( Valid_2 )
							 case( k )
								 1 :
								 begin
								    if( ( i == 0 ) && ( j == 1 ) && ( k < 2 ) )
									 begin
										 Mask[2][1] <= dout;
										 Mask[2][2] <= Mask[2][1];
										 Mask[2][3] <= Mask[2][2];
									 end
									 else 
									 begin
										 Mask[3][1] <= dout;
										 Mask[3][2] <= Mask[3][1];
										 Mask[3][3] <= Mask[3][2];
									 end
								 end
								 2 :
								 begin
								    if( ( i == 0 ) && ( j == 1 ) && ( k < 2 ) )
									 begin
										 Mask[2][1] <= dout;
										 Mask[2][2] <= Mask[2][1];
										 Mask[2][3] <= Mask[2][2];
									 end
									 else
									 begin
										 Mask[1][1] <= dout;
										 Mask[1][2] <= Mask[1][1];
										 Mask[1][3] <= Mask[1][2];
									 end
								 end
								 3 :
								 begin
								       Mask[2][1] <= dout;
									    Mask[2][2] <= Mask[2][1];
									    Mask[2][3] <= Mask[2][2];
								 end
							 endcase
					 end
					 else if( j==0 )
					 begin
					    if ( Valid_Input )
							 case( k )
								 1 : addra <= i + Column;
								 2 : addra <= i;
								 3 : if ( i == Column - 1 ) addra <= 2 * Column;
							 endcase
						 
						 if( Valid_2 )
							 case( k )
								 1 :
								 begin
								    Mask[2][1] <= dout;
									 Mask[2][2] <= Mask[2][1];
									 Mask[2][3] <= Mask[2][2];
								 end
								 2 :
								 begin
								    Mask[3][1] <= 0;
									 Mask[3][2] <= Mask[3][1];
									 Mask[3][3] <= Mask[3][2];
								 end
								 3 :
								 begin
								    Mask[1][1] <= dout;
									 Mask[1][2] <= Mask[1][1];
									 Mask[1][3] <= Mask[1][2];
								 end
							 endcase
					 end
					 else 
					 begin
						 if ( Valid_Input )
							 case( k )
								 2:addra <= i + ( Row - 1 ) * Column;
								 3:
								 begin
									 if ( i == Column - 1 ) addra <= Column;
									 else addra <= i + 1 + ( Row - 2 ) * Column;
								 end
							 endcase
						 
						 if( Valid_2 )
							 case( k )
								 1:
								 begin
								    Mask[2][1] <= dout;
									 Mask[2][2] <= Mask[2][1];
									 Mask[2][3] <= Mask[2][2];
								 end
								 2:
								 begin
								    Mask[3][1] <= dout;
									 Mask[3][2] <= Mask[3][1];
									 Mask[3][3] <= Mask[3][2];
								 end
								 3:
								 begin
								    Mask[1][1] <= 0;
									 Mask[1][2] <= Mask[1][1];
									 Mask[1][3] <= Mask[1][2];
								 end
							 endcase
					 end
				 end
			 end
		 end
	 end
//------------------------------------------------------------	 	 
	 always @(posedge CLK_OUT75)
	 begin   
		 if ( s )
	    begin
		    if ( j < Row )
			 begin
				 if ( i < Column )
				 begin
				    if( Valid_Input )
						 case( k )
							 1 :
							 begin
								 k <= 2;
							 end
							 2 :
							 begin
								 k <= 3;
							 end
							 3 :
							 begin
								 k <= 1;
								 if( i < Column - 1 ) i <= i + 1;
								 else 
								 begin
									 i <= 0;
									 j <= j+1;
									 if ( j == Row - 1 )
									 begin
									    j <= 0;
										 i <= 0;
										 k <= 2;
									 end
								 end
							 end
						 endcase
				 end
			 end
		 end
	 end

//------------------------------------------------------------	      
	  Sobel MySob ( 
		.a3(Mask[1][1]), 
		.a6(Mask[2][1]), 
		.a9(Mask[3][1]), 
		.clk_Sobel(CLK_OUT25), 
		.Valid(Valid_2), 
		.Valid_Filter(Valid_Sobel), 
		.Pixel_Sobel(Pixel_Sobel)
	);
	
	Median_Filters MyMed (
		.a1(Mask[1][3]), 
		.a2(Mask[1][2]), 
		.a3(Mask[1][1]), 
		.a4(Mask[2][3]), 
		.a5(Mask[2][2]), 
		.a6(Mask[2][1]), 
		.a7(Mask[3][3]), 
		.a8(Mask[3][2]), 
		.a9(Mask[3][1]), 
		.clk_Median(CLK_OUT25), 
		.Valid(Valid_3), 
		.Valid_filter(Valid_Median), 
		.Pixel_Median(Pixel_Median)
	);
//------------------------------------------------------------	 
	always @(posedge CLK_OUT25)
	begin
	   case( Filter )
		   0 : Pixel <= Pixel_Sobel;
		   1 : Pixel <= Pixel_Median;
			3 : Pixel <= Mask[2][2];
		endcase
	end
//------------------------------------------------------------	 
	always @(posedge CLK_OUT25)
		if( LOCKED )
		begin
			case( Filter )
				0 : Valid <= Valid_Sobel;
				1 : Valid <= Valid_Median;
				3 : Valid <= Valid_2;
			endcase
		end
//------------------------------------------------------------		
	always @(posedge CLK_OUT25)
	begin
	   case( Filter )
		   0 : Pixel_address <= Pixel_Address4;
		   1 : Pixel_address <= Pixel_Address5;
			3 : Pixel_address <= Pixel_Address1;
			default : Pixel_address <= 0;
		endcase
	end	
//------------------------------------------------------------	
	
	always @(posedge CLK_OUT25)
		if( s )
		begin
			Valid_1 <= Valid_Input;
			Valid_2 <= Valid_1;
			Valid_3 <= Valid_2;
		end 
//------------------------------------------------------------	
	always @(posedge CLK_OUT25)
	begin
	   if ( ( i > 2 ) || ( j != 0 ) ) Pixel_Address1 <= Pixel_Address1 + 1;
		if ( Pixel_Address1 == Column * Row - 1 ) Pixel_Address1 <= 0;
	end
//------------------------------------------------------------ 	
	always @(posedge CLK_OUT25)
	begin
	   Pixel_Address2 <= Pixel_Address1;
		Pixel_Address3 <= Pixel_Address2;
		Pixel_Address4 <= Pixel_Address3;
		Pixel_Address5 <= Pixel_Address4; 
	end 
//------------------------------------------------------------ 
endmodule
