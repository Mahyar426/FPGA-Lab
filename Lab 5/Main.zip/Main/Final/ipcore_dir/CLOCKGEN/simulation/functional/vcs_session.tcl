gui_open_window Wave
gui_sg_create CLOCKGEN_group
gui_list_add_group -id Wave.1 {CLOCKGEN_group}
gui_sg_addsignal -group CLOCKGEN_group {CLOCKGEN_tb.test_phase}
gui_set_radix -radix {ascii} -signals {CLOCKGEN_tb.test_phase}
gui_sg_addsignal -group CLOCKGEN_group {{Input_clocks}} -divider
gui_sg_addsignal -group CLOCKGEN_group {CLOCKGEN_tb.CLK_IN1}
gui_sg_addsignal -group CLOCKGEN_group {{Output_clocks}} -divider
gui_sg_addsignal -group CLOCKGEN_group {CLOCKGEN_tb.dut.clk}
gui_list_expand -id Wave.1 CLOCKGEN_tb.dut.clk
gui_sg_addsignal -group CLOCKGEN_group {{Status_control}} -divider
gui_sg_addsignal -group CLOCKGEN_group {CLOCKGEN_tb.RESET}
gui_sg_addsignal -group CLOCKGEN_group {CLOCKGEN_tb.LOCKED}
gui_sg_addsignal -group CLOCKGEN_group {{Counters}} -divider
gui_sg_addsignal -group CLOCKGEN_group {CLOCKGEN_tb.COUNT}
gui_sg_addsignal -group CLOCKGEN_group {CLOCKGEN_tb.dut.counter}
gui_list_expand -id Wave.1 CLOCKGEN_tb.dut.counter
gui_zoom -window Wave.1 -full
