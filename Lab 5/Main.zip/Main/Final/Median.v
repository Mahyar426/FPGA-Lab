`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    00:54:24 06/11/2021 
// Design Name: 
// Module Name:    Median 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Median(
input clkMedian , Valid ,
input [7:0] A1 , A2 , A3 ,
output reg Valid_Median = 0 ,
output reg [7:0] Mean1 = 0
    );
//------------------------------------------------------------	 
	 reg Valid_reg = 0;
	 reg [7:0] a1 = 0 , a2 = 0 , a3 = 0;
//------------------------------------------------------------	 
	 always @(posedge clkMedian)
	 begin
	    if ( Valid )
		 begin
			 a1 <= A1;
			 a2 <= A2;
			 a3 <= A3;
		 end
	 end
//------------------------------------------------------------	 
	 always @(posedge clkMedian)
	 begin
	    if ( Valid_reg )
		 begin
			 if ( a1 > a2 )
			 begin
				 if( a3 >= a1 )
					 Mean1 <= a1;
				 else if ( a3 >= a2 )
					 Mean1 <= a3;
				 else 
					 Mean1 <= a2;
			 end
			 
			 else
			 begin
				 if( a3 >= a2 )
					 Mean1 <= a2;
				 else if ( a3 >= a1 )
					 Mean1 <= a3;
				 else 
					 Mean1 <= a1;
			 end
	    end
	 end
//------------------------------------------------------------	 
	 always @(posedge clkMedian)
	    Valid_reg <= Valid;
//------------------------------------------------------------	 
	 always @(posedge clkMedian)
	    Valid_Median <= Valid_reg;
//------------------------------------------------------------
endmodule
