
# PlanAhead Launch Script for Post-Synthesis floorplanning, created by Project Navigator

create_project -name Final -dir "C:/Users/Mahyar Onsori/Desktop/Az 5/Main/Final/planAhead_run_1" -part xc6slx9tqg144-3
set_property design_mode GateLvl [get_property srcset [current_run -impl]]
set_property edif_top_file "C:/Users/Mahyar Onsori/Desktop/Az 5/Main/Final/Top.ngc" [ get_property srcset [ current_run ] ]
add_files -norecurse { {C:/Users/Mahyar Onsori/Desktop/Az 5/Main/Final} {ipcore_dir} }
add_files [list {ipcore_dir/ROM_Median.ncf}] -fileset [get_property constrset [current_run]]
add_files [list {ipcore_dir/ROM_Sobel.ncf}] -fileset [get_property constrset [current_run]]
set_property target_constrs_file "Top.ucf" [current_fileset -constrset]
add_files [list {Top.ucf}] -fileset [get_property constrset [current_run]]
link_design
