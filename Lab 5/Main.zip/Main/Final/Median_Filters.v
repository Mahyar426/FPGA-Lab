`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    00:55:26 06/11/2021 
// Design Name: 
// Module Name:    Median_Filters 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Median_Filters(
input clk_Median , Valid ,
input [7:0] a1 , a2 , a3 , a4 , a5 , a6 , a7 , a8 , a9 ,
output Valid_filter ,
output [7:0] Pixel_Median
    );
//------------------------------------------------------------	 
	 wire Valid_Median;
	 wire [7:0] Mean1 , Mean2 , Mean3;
//------------------------------------------------------------	 
   Median M1 (
		.A1(a1), 
		.A2(a2), 
		.A3(a3), 
		.clkMedian(clk_Median), 
		.Valid(Valid), 
		.Valid_Median(Valid_Median), 
		.Mean1(Mean1)
	);
//------------------------------------------------------------
   Median M4 (
		.A1(a4), 
		.A2(a5), 
		.A3(a6), 
		.clkMedian(clk_Median), 
		.Valid(Valid), 
		.Valid_Median( ), 
		.Mean1(Mean2)
	);
//------------------------------------------------------------	 
   Median M7 (
		.A1(a7), 
		.A2(a8), 
		.A3(a9), 
		.clkMedian(clk_Median), 
		.Valid(Valid), 
		.Valid_Median( ), 
		.Mean1(Mean3)
	);
//------------------------------------------------------------	 
   Median MT (
		.A1(Mean1), 
		.A2(Mean2), 
		.A3(Mean3), 
		.clkMedian(clk_Median), 
		.Valid(Valid_Median), 
		.Valid_Median(Valid_filter), 
		.Mean1(Pixel_Median)
	);
//------------------------------------------------------------
endmodule
