`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    00:53:28 06/11/2021 
// Design Name: 
// Module Name:    Sobel 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Sobel(
input clk_Sobel , Valid ,
input [7:0] a3 , a6 , a9 ,
output reg Valid_Filter = 0 ,
output reg [7:0] Pixel_Sobel = 0
    );
//------------------------------------------------------------	 
	 parameter Threshold = 110;
	 reg Valid_A = 0 , Valid_Sum = 0;
	 reg [9:0] Sumx_1 = 0 , Sumx_2 = 0 , Sumx_3 = 0;
	 reg signed [9:0] Sumy_1 = 0 ,  Sumy_2 = 0 , Sumy_3 = 0;	
	 reg signed [11:0] Ax = 0 , Ay = 0 , Ax_Abs = 0 , Ay_Abs = 0;
//------------------------------------------------------------	 
	 always @(posedge clk_Sobel)
	 begin
	    if ( Valid == 1 )
		 begin
			 Sumy_1 <= a9 - a3;
			 Sumy_2 <= Sumy_1;
			 Sumy_3 <= Sumy_2;
			
			 Sumx_1 <= a3 + ( a6 * 2 ) + a9;
			 Sumx_2 <= Sumx_1;
			 Sumx_3 <= Sumx_2;
		 end
	 end
//------------------------------------------------------------	 
	 always @(posedge clk_Sobel)
	 begin
	    if ( Valid_Sum == 1 )
		 begin
			 Ax <= Sumx_1 - Sumx_3 ;
			 Ay <= ( Sumy_3 ) + ( ( Sumy_2 ) * 2 ) + ( Sumy_1 );
			 
			 if( Ax < 0 ) Ax_Abs <= -Ax;
			 else Ax_Abs <= Ax;
			 
			 if( Ay < 0 ) Ay_Abs <= -Ay;
			 else Ay_Abs <= Ay;
		 end
	 end
//------------------------------------------------------------	 
	 always @(posedge clk_Sobel)
	 begin
	    if ( Valid_A == 1 )
		 begin
			 if( Ax_Abs + Ay_Abs > Threshold )
				 Pixel_Sobel <= 255;
			 
			 else
				 Pixel_Sobel <= 0;
		 end
	 end
//------------------------------------------------------------	 
	 always @(posedge clk_Sobel)
	    Valid_Sum <= Valid;
//------------------------------------------------------------		 
	always @(posedge clk_Sobel)
	    Valid_A <= Valid_Sum;
//------------------------------------------------------------	 
	 always @(posedge clk_Sobel)
	    Valid_Filter <= Valid_A;
//------------------------------------------------------------	 
endmodule
