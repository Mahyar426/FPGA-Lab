`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    00:36:54 06/11/2021 
// Design Name: 
// Module Name:    Resize 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Size(
input valid_input,clk,clkb,
input [7:0] pix_in,
input [1:0] size,
output reg [31:0] pix=0,
output reg [20:0] Pixel_Address=0,
output reg valid_out=0
    );
	 
	 parameter column=640;
	 parameter row=480;
	 
	 reg [21 : 0] addr=0;
	 reg [11 : 0] addrb=0;
	 reg [7 : 0] A1=0;
	 reg [7 : 0] A2=0;
	 reg [7 : 0] A3=0;
	 reg [7 : 0] A4=0;
	 reg s=0;
	 reg [1:0] k=0;
	 reg [8:0] i=0;
	 reg [13:0] j=0;
	 wire [7 : 0] doutb;
	 
	 reg [11:0] x=0;
	 
	 reg valid_2=0;
	 reg valid_half=0;
	 reg valid_ram=0;
	 reg valid_A=0;
	 reg valid_sync=0;
	 reg valid_sync1=0;
	 reg h=1;
	 
	 
	 reg [7:0] pix_1=0;
	 reg [7:0] pix_2=0;
	 reg [7:0] pix_3=0;
	 reg [7:0] pix_sync=0;
	 reg [7:0] pix_sync1=0;
	 reg [7:0] pix_sync2=0;
	 reg [7:0] pix_sync3=0;
	 reg [7:0] pix_sync4=0;

	 always @(posedge clk)
	 begin
	    if(valid_input==1)
		 begin
		    addr<=addr+1;
		 end
	 end
	 
//	 always @(posedge clk)    //00
//		 if(valid_ram==1 && size==0)
//		 begin
//			 pix_1<=pix_in;
////			 addrb<=addrb+1;
//		 end
	 
	 
	 
	 always @(posedge clkb)
	 begin
//	    if(valid_A)
	       pix_sync<=pix_2;
//		 if(valid_A)
		    pix_sync1<=pix_sync;
//		 if(valid_A)
		    pix_sync2<=pix_sync1;
			 
			 pix_sync3<=pix_sync2;
			 
			 pix_sync4<=pix_sync3;
	 end
	 
	 always @(posedge clk)
	 begin
	    if(valid_input)
	       valid_ram<=valid_input;
		 if((addr>2*column)|s==1)   
		    valid_A<=valid_ram;
//		 if(valid_A)
//		    valid_2<=valid_A;
//		 if(valid_2)
//		    valid_sync<=valid_2;
//		 if(valid_sync)
//		    valid_sync1<=valid_sync;
	 end
	 
	 always @(posedge clk)
	 begin
	    if(valid_input)
		 begin
		    x<=x+1;
			 if(x==column-1)
			 begin
			    x<=0;
				 h<=!h;
			 end
//			 if(h==1)
//			    valid_half<=!valid_half;   00
		 end
	 end
	 
	 
	 always @(posedge clkb)
	 begin
	    case (size)
		 0,2:begin    // valid_ram
		    pix<=pix_in;
		 end
		 1:begin
		    pix<={pix[23:0],pix_sync4};
		 end
		 endcase
	 end
	 
	 always @(posedge clk)
	 begin
	    case (size)
		 0:begin    // valid_ram
		    valid_out<=valid_input;
		 end
		 1:begin
		    if((addr>2*column)|s==1)
		      valid_out<=valid_input;
		 end
		 2:begin
		    if(h==1 && valid_input)
			    valid_out<=!valid_out;
			 else
			    valid_out<=0;
		 end
		 endcase
	 end
	 
	 always @(posedge clk)
	 begin
	    case (size)
		 0:begin		 // valid_ram
		    if(valid_input)
			    Pixel_Address<=Pixel_Address+1;
		 end
		 1:begin
			 if(valid_A)
			 begin
				 Pixel_Address<=Pixel_Address+1;
			 end
		 end
		 2:begin
		    if(h==1 && valid_out==1)
			    Pixel_Address<=Pixel_Address+1;
		 end
		 endcase
	 end
	 
	 
	 ram_ofresize your_instance_name (
  .clka(clk), // input clka
  .wea(valid_input), // input [0 : 0] wea
  .addra(addr[11:0]), // input [11 : 0] addra
  .dina(pix_in), // input [7 : 0] dina
  .clkb(clkb), // input clkb
  .addrb(addrb), // input [11 : 0] addrb
  .doutb(doutb) // output [7 : 0] doutb
);


endmodule
