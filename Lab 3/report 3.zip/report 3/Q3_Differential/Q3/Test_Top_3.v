`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   23:22:09 05/10/2021
// Design Name:   Top_Q3
// Module Name:   C:/Users/Mahyar Onsori/Desktop/New folder/report 3/Q3/Q3/Test_Top_3.v
// Project Name:  Q3
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: Top_Q3
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module Test_Top_3;

	// Inputs 
	reg clk;
	reg IRx;
	reg IB;
	reg [7:0] Data_in;  
	reg Start;

	// Outputs
	wire OTx;
	wire OB;
	wire Data_valid_out;
	wire [7:0] Data_Out;

	// Instantiate the Unit Under Test (UUT)
	Top_Q3 uut (
		.clk(clk), 
		.IRx(IRx), 
		.IB(IB), 
		.Data_in(Data_in), 
		.Start(Start), 
		.OTx(OTx), 
		.OB(OB), 
		.Data_valid_out(Data_valid_out), 
		.Data_Out(Data_Out)
	);
	
	
	
	

initial begin
		// Initialize Inputs
		clk = 0;
		Data_in = 0;
		Start = 0;

		@(negedge clk) Start <= 1;
		Data_in <=8'b10110001;
		@(negedge clk) Start <=0;
		#900; 
 
      
		@(negedge clk) Start <= 1;
		Data_in <=8'b00011010;
		@(negedge clk) Start <=0;
		#900;
      
		@(negedge clk) Start <= 1;
	   Data_in <=8'b00111100;
		@(negedge clk) Start <=0;
		#900;
	   
		@(negedge clk) Start <= 1;
		Data_in <=8'b11101110;
		@(negedge clk) Start <=0;
		  
	end
	
always @(*)begin
	IRx = OTx;
	IB = OB;
end
	
always #25 clk <= ~clk;

      
endmodule


