`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    23:17:00 05/10/2021 
// Design Name: 
// Module Name:    Top_Q3 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Top_Q3(
    input clk,
    input IRx,
    input IB,  
	 input Start,
    input [7:0] Data_in,
    output OTx,
    output OB,
    output Data_valid_out,
    output [7:0] Data_Out
    );
//--------------------------------------
wire Tx;
wire Rx;
//--------------------------------------
uart_sender Transmitter (  
		.clk(clk), 
		.Data_in(Data_in), 
		.Start(Start),
		.Data_out(Tx)
	);
//--------------------------------------	
OBUFDS o1(	 
	  .I(Tx),
     .O(OTx), 
     .OB(OB)	  
);	 
//--------------------------------------
IBUFDS o2(
     .I(IRx),
	  .IB(IB),
	  .O(Rx)
);
//--------------------------------------
uart_reciever Reciever(
		.clk(clk), 
		.Data_in(Rx), 
		.Data_out(Data_Out), 
		.Data_valid(Data_valid_out)
	);
//--------------------------------------
endmodule
