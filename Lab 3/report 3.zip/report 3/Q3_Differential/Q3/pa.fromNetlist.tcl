
# PlanAhead Launch Script for Post-Synthesis pin planning, created by Project Navigator

create_project -name Q3 -dir "C:/Users/Mahyar Onsori/Desktop/New folder/report 3/Q3_Differential/Q3/planAhead_run_1" -part xc6slx9tqg144-3
set_property design_mode GateLvl [get_property srcset [current_run -impl]]
set_property edif_top_file "C:/Users/Mahyar Onsori/Desktop/New folder/report 3/Q3_Differential/Q3/Top_Q3.ngc" [ get_property srcset [ current_run ] ]
add_files -norecurse { {C:/Users/Mahyar Onsori/Desktop/New folder/report 3/Q3_Differential/Q3} }
set_param project.pinAheadLayout  yes
set_property target_constrs_file "Top_Q3.ucf" [current_fileset -constrset]
add_files [list {Top_Q3.ucf}] -fileset [get_property constrset [current_run]]
link_design
