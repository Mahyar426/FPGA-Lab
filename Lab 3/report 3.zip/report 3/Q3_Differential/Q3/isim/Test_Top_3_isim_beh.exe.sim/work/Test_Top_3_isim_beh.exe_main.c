/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000000484744034_1600196784_init();
    unisims_ver_m_00000000004146189403_3839349792_init();
    unisims_ver_m_00000000003003270080_0848181053_init();
    work_m_00000000003585453854_1891356351_init();
    work_m_00000000001176452674_1250659698_init();
    work_m_00000000001821128020_0249392378_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000001821128020_0249392378");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
