
# PlanAhead Launch Script for Post-Synthesis pin planning, created by Project Navigator

create_project -name uart_module -dir "C:/Users/Mahyar Onsori/Desktop/New folder/report 3/Q1_UART_module/planAhead_run_3" -part xc6slx9tqg144-3
set_property design_mode GateLvl [get_property srcset [current_run -impl]]
set_property edif_top_file "C:/Users/Mahyar Onsori/Desktop/New folder/report 3/Q1_UART_module/uart_top_module.ngc" [ get_property srcset [ current_run ] ]
add_files -norecurse { {C:/Users/Mahyar Onsori/Desktop/New folder/report 3/Q1_UART_module} }
set_param project.pinAheadLayout  yes
set_property target_constrs_file "uart_top_module.ucf" [current_fileset -constrset]
add_files [list {uart_top_module.ucf}] -fileset [get_property constrset [current_run]]
link_design
