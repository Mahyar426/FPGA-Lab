`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    17:56:31 05/10/2021 
// Design Name: 
// Module Name:    uart_top_module 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module uart_top_module(
    input clk,
    input [7:0] Data_in,
	 input Start ,
	 input Rx ,
	 output Tx ,
    output [7:0] Data_out ,
	 output data_valid_out
    );
//------------------------------------
uart_sender my_sender (
    .clk(clk), 
    .Data_in(Data_in), 
    .Start(Start), 
    .Data_out(Tx)
    );
//------------------------------------
uart_reciever my_reciever (  
    .clk(clk), 
    .Data_in(Rx), 
    .Data_valid(data_valid_out), 
    .Data_out(Data_out)
    );
//------------------------------------
endmodule
