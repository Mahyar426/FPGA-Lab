`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    22:17:17 04/04/2020 
// Design Name: 
// Module Name:    reciever 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module uart_reciever(
    input clk,
    input Data_in,
    output reg [7:0] Data_out = 0,
    output reg Data_valid = 0
    );
//------------------------------------
reg [7:0] Uart_Data=0;
reg[3:0] cnt=0;
reg Start=0;
//------------------------------------
always@(posedge clk) begin
  Data_valid <=0;
  if(Data_in==0) Start<=1'b1;
  if(Start) begin
    cnt<=cnt + 1'b1;
	 Uart_Data<={Data_in,Uart_Data[7:1]};
	 if(cnt == 7) Start <= 0;
  end 
  if(cnt==8) begin
  	 cnt<=0;
	 Data_out<=Uart_Data;
    Data_valid<=1; 
  end
end
//------------------------------------	
endmodule
