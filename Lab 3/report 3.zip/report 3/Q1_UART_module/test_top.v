`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   18:18:26 05/10/2021
// Design Name:   uart_top_module
// Module Name:   C:/Users/Mahyar Onsori/Desktop/New folder/report 3/uart_module/test_top.v
// Project Name:  uart_module
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: uart_top_module
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module test_top;

	// Inputs
	reg clk;
	reg [7:0] Data_in;
	reg Start;
   reg Rx;
	// Outputs
	wire Tx;
	wire [7:0] Data_out;
	wire data_valid_out;

	// Instantiate the Unit Under Test (UUT)
	uart_top_module uut (
		.clk(clk), 
		.Data_in(Data_in), 
		.Start(Start), 
		.Rx(Rx), 
		.Tx(Tx),  
		.Data_out(Data_out), 
		.data_valid_out(data_valid_out)
	);

	initial begin
		// Initialize Inputs
		clk = 0;
		Data_in = 0;
		Start = 0;

		// Wait 100 ns for global reset to finish
		//#500;
        
		// Add stimulus here
      @(negedge clk) 
		begin 
		Start=1;
		Data_in=8'b10100011;
		end
		@(negedge clk)
		begin
		Start=0;
		end
		#1000;
		//------------------------------------
		@(negedge clk) 
		begin 
		Start=1;
		Data_in=8'b10111010;
		end
		@(negedge clk)
		begin
		Start=0;
		end
		#1000;
		//------------------------------------
		@(negedge clk) 
		begin 
		Start=1;
		Data_in=8'b00001100; 
		end 
		@(negedge clk)
		begin
		Start=0;
		end
		#1000;				
	end
      //--------------------------------	
      always @(*) begin
         	Rx = Tx;
      end	
		
		
      always #12.5 clk<=~clk;      
endmodule

