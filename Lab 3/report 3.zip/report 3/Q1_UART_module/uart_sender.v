`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    18:07:32 05/10/2021 
// Design Name: 
// Module Name:    uart_sender 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module uart_sender(
   input clk ,
	input [7:0] Data_in ,
	input Start ,
   output Data_out
	);
//-------------------------------------------------
reg [3:0] cnt = 4'b0000;
reg [9:0] shift_register = 10'b1111111111;
//-------------------------------------------------
always @(posedge clk)
 begin
  if(Start) shift_register <= {1'b1,Data_in,1'b0};
  else shift_register <= {1'b1,shift_register[9:1]};
 end
//-------------------------------------------------
assign Data_out = shift_register[0];
//-------------------------------------------------
always @(posedge clk)
 begin
  if(Start == 0) cnt <= cnt + 1; 
  else if(cnt == 10) cnt <= 10;
  else  cnt <= 0;
 end
//-------------------------------------------------
endmodule 
