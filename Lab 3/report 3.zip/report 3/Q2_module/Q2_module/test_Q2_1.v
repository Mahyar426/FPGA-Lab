`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   19:28:47 05/10/2021
// Design Name:   Top_Module
// Module Name:   C:/Users/Mahyar Onsori/Desktop/New folder/report 3/Q2_module/Q2_module/test_Q2_1.v
// Project Name:  Q2_module
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: Top_Module
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module test_Q2_1;

	// Inputs 
	reg clk;
	reg Rx;
	reg Start;
	reg [2:0] Address;

	// Outputs
	wire Tx;
	wire Finished;
	wire LED;
	wire [7:0] Out;

	// Instantiate the Unit Under Test (UUT)
	Top_Module uut (
		.clk(clk), 
		.Rx(Rx), 
		.Tx(Tx), 
		.Start(Start), 
		.Address(Address), 
		.Finished(Finished), 
		.LED(LED), 
		.Out(Out)
	);
	
	
always @(*) begin
	Rx=Tx;
end

initial begin
		// Initialize Inputs
		Start = 0;
		clk = 0;
		Address =0;
		 

     @(negedge clk) Start <=1; 
		#10000;
		Address =4;
		#10000;
		
		Address =7;
		#10000;
		
		Address =1;
		#10000; 
		
		Address =2;
		#10000;
		
		Address =5;
		#10000;
		 
		@(negedge clk) Start <=0;
        
		end
always #20.83 clk <= ~clk;

endmodule