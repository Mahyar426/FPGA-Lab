
# PlanAhead Launch Script for Post-Synthesis pin planning, created by Project Navigator

create_project -name Q2_module -dir "C:/Users/Mahyar Onsori/Desktop/New folder/report 3/Q2_module/Q2_module/planAhead_run_2" -part xc6slx9tqg144-3
set_property design_mode GateLvl [get_property srcset [current_run -impl]]
set_property edif_top_file "C:/Users/Mahyar Onsori/Desktop/New folder/report 3/Q2_module/Q2_module/Top_Module.ngc" [ get_property srcset [ current_run ] ]
add_files -norecurse { {C:/Users/Mahyar Onsori/Desktop/New folder/report 3/Q2_module/Q2_module} {ipcore_dir} }
add_files [list {ipcore_dir/MY_RAM.ncf}] -fileset [get_property constrset [current_run]]
add_files [list {ipcore_dir/MY_ROM.ncf}] -fileset [get_property constrset [current_run]]
set_param project.pinAheadLayout  yes
set_property target_constrs_file "Top_Module.ucf" [current_fileset -constrset]
add_files [list {Top_Module.ucf}] -fileset [get_property constrset [current_run]]
link_design
