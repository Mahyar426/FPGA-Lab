/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    xilinxcorelib_ver_m_00000000001358910285_0839870129_init();
    xilinxcorelib_ver_m_00000000001687936702_2949114950_init();
    xilinxcorelib_ver_m_00000000000277421008_0739283008_init();
    xilinxcorelib_ver_m_00000000001603977570_2560814816_init();
    work_m_00000000002489990758_3544636632_init();
    xilinxcorelib_ver_m_00000000000277421008_3475695161_init();
    xilinxcorelib_ver_m_00000000001603977570_0110273700_init();
    work_m_00000000000403262735_1304818006_init();
    work_m_00000000000484744034_1600196784_init();
    work_m_00000000003585453854_1891356351_init();
    work_m_00000000003090422609_3883954941_init();
    work_m_00000000002381100472_1446268862_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000002381100472_1446268862");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
