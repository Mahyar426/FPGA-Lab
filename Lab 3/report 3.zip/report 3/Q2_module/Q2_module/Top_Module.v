`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    19:18:03 05/10/2021 
// Design Name: 
// Module Name:    Top_Module 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Top_Module(
    input clk,
    input Rx,
    output Tx,
    input Start,
    input [2:0] Address,
    output reg Finished=0,
    output reg LED=0,
    output [7:0] Out 
    );
//----------------------------------------------	 
reg Clock9600=0;
reg flag=0;
//----------------------------------------------
reg [2:0] ROMAddress;
reg [2:0] RAMAddress;
reg [2:0] AddressROM=0;
reg [2:0] AddressRAM=0; 
//----------------------------------------------
reg Start_Transmit=0;            
wire Data_valid_Reciever; 
wire [7:0] douta;
wire [7:0] Reciever_Out;
//----------------------------------------------
reg [3:0]  counter_finish=0;
reg [3:0]  counter_address=0;
reg [10:0] counter_clk=0;
//----------------------------------------------
MY_ROM First_ROM(
  .clka(clk),
  .addra(ROMAddress), 
  .douta(douta) 
);
//----------------------------------------------
MY_RAM First_RAM (
  .clka(clk),  
  .wea(Data_valid_Reciever),  
  .addra(RAMAddress), 
  .dina(Reciever_Out), 
  .douta(Out)  
);
//----------------------------------------------
uart_sender Transmitter (
		.clk(Clock9600),                
		.Data_in(douta),                
		.Start(Start_Transmit),        
		.Data_out(Tx)                        
	);
//----------------------------------------------
uart_reciever Reciever (
		.clk(Clock9600),                 
		.Data_in(Rx),                        
		.Data_out(Reciever_Out),      
		.Data_valid(Data_valid_Reciever)         
	);
//----------------------------------------------
always@(posedge clk) begin
	if(Start==1) counter_finish<=0;
   counter_clk<=counter_clk + 1'b1;
	if(counter_clk==1250) begin
	   Clock9600<=~Clock9600;
		counter_clk<=0;
		if(Data_valid_Reciever==1) begin
		   if(Clock9600==1)  counter_finish<=counter_finish + 1'b1;
		end
	end
end
//----------------------------------------------
always @(posedge clk) begin
   Finished<=0;
	if(counter_finish==8) Finished<=1;
end
//----------------------------------------------
always @(*) begin
   if(Finished==1) begin
   ROMAddress<=Address;
   RAMAddress<=Address;
   end
   else begin
   ROMAddress<=AddressROM;
   RAMAddress<=AddressRAM;
	end
end
//----------------------------------------------
always@(posedge clk) begin

	if(Start==1) begin 
	   flag<=1;
		Start_Transmit<=1;
		counter_address<=0;
		AddressROM<=0;
		AddressRAM<=0;
	end 
	
	
	if(flag==1) begin
	    if((counter_clk==1250) &&(Clock9600==1)) begin
		     counter_address<=counter_address + 1'b1;
			  Start_Transmit<=0;
			  if(Data_valid_Reciever==1) AddressRAM<=AddressRAM +1'b1;
			  if(AddressRAM==7) flag<=0;
		 end
		 if(counter_address==11) begin
		 	  counter_address<=0;
		     AddressROM<=AddressROM + 1'b1;
			  Start_Transmit<=1;
		 end
	end	
end
//----------------------------------------------
always@(posedge clk) begin
LED<=0;
  if((douta==Out)) begin
	    LED<=1; 
  end
end 	
//----------------------------------------------	
endmodule
