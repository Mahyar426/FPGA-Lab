`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    13:27:58 06/23/2021 
// Design Name: 
// Module Name:    Top 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
module Top(
    input clk,
    input RXF,
    input TXE,
    output reg RD = 1,
    output reg WR = 1,
    inout [7:0] Data
    );
//------------------------------------------	 
reg [ 7 : 0 ] Datareg = 8'b00000000;
reg [ 7 : 0 ] Counter = 8'b00000001;
reg Flag = 0;
//------------------------------------------
always @( posedge clk ) 
begin

    if( RXF == 0 ) 
	 begin
	      RD <= 0;
	 end
	 
	 
	 if ( RD == 0 )
	 begin
	      Datareg <= Data;
		   RD <= 1;
	 end
	 
end
//------------------------------------------

always @( posedge clk )
begin
      if ( Counter <= Datareg )
		begin
		
		     if ( TXE == 0 )
			  begin
			       Flag <= 1;
			  end
			  
		     
			  if ( Flag == 1 )
			  begin
			       WR <= 0;
			  end
			  
			  
			  if ( WR == 0 )
			  begin
			       WR   <= 1;
					 Flag <= 0;
			  end
			  
		end
end
//------------------------------------------
always @ ( posedge clk )
begin
      if ( RD == 0 )
		begin
		      Counter <= 1;
		end
		
		else if ( WR == 0 )
		begin
		
		     if ( Counter <= Datareg ) 
			  begin
			        Counter <= Counter + 1;
			  end
			  
		end
end
//------------------------------------------
assign Data = Flag ? Counter : 8'bzzzzzzzz ;
	   

endmodule
