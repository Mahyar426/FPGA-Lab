`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   19:20:36 06/23/2021
// Design Name:   Top
// Module Name:   C:/Users/Mahyar Onsori/Desktop/New folder/p6/Az6/Test.v
// Project Name:  Az6
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: Top
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module Test;

	// Inputs
	reg clk;
	reg RXF;
	reg TXE;

	// Outputs
	wire RD;
	wire WR;

	// Bidirs
	wire [7:0] Data;

	// Instantiate the Unit Under Test (UUT)
	Top uut (
		.clk(clk), 
		.RXF(RXF), 
		.TXE(TXE), 
		.RD(RD), 
		.WR(WR), 
		.Data(Data)
	);

	initial begin
		// Initialize Inputs
		clk = 0;
		RXF = 1;
		TXE = 1;

		// Wait 100 ns for global reset to finish
		#100;
        
		// Add stimulus here
		
		@(negedge clk) force Data = 8'b00011010;
		@(negedge clk) RXF = 0;
	   @(negedge clk) RXF = 1;
		#50;
		release Data ;
		#150;
		@(negedge clk) TXE = 0;

	end

always #20.833 clk <= ~ clk ;      
endmodule

